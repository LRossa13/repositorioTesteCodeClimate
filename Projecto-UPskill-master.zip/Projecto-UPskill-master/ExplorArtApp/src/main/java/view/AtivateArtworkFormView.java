package view;

import javafx.scene.Parent;
import model.*;

public class AtivateArtworkFormView extends Parent {
    public AtivateArtworkFormView(Obra_Arte obraArte, Artista artista, Tecnica tecnica, Movimento movimento, Materiais material) {


    }
}
