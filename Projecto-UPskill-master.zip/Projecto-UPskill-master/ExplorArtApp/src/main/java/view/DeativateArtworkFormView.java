package view;

import javafx.scene.Parent;
import model.*;

public class DeativateArtworkFormView extends Parent {
    public DeativateArtworkFormView(Obra_Arte obraArte, Artista artista, Tecnica tecnica, Movimento movimento, Materiais material) {
    }
}
