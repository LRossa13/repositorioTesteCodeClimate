package artsymodel;

public class ArtsyGene {
    private String name;

    public ArtsyGene(String name) {
        this.name = name;
    }

    public ArtsyGene() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}
